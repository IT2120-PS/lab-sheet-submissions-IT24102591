getwd()

setwd("C:\\Users\\user\\Desktop\\IT24102591 LAB_08")
laptop_data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

popmean_weight <- mean(laptop_data$Weight)
popvar_weight <- var(laptop_data$Weight) * (length(laptop_data$Weight) - 1) / length(laptop_data$Weight)
popsd_weight <- sqrt(popvar_weight)

cat("Population Mean:", round(popmean_weight, 4), "kg\n")
cat("Population Standard Deviation:", round(popsd_weight, 4), "kg\n\n")

set.seed(456)
samples_weight <- matrix(nrow = 6, ncol = 25)
for(i in 1:25) {
  samples_weight[, i] <- sample(laptop_data$Weight, 6, replace = TRUE)
}

s.means_weight <- apply(samples_weight, 2, mean)
s.sd_weight <- apply(samples_weight, 2, sd)

cat("| Sample | Mean | Standard Deviation |\n")
cat("|---|---|---|\n")
for(i in 1:15) {
  cat("|", i, "|", round(s.means_weight[i], 4), "|", round(s.sd_weight[i], 4), "|\n")
}
cat("\n")

cat("| Sample | Mean | Standard Deviation |\n")
cat("|---|---|---|\n")
for(i in 16:25) {
  cat("|", i, "|", round(s.means_weight[i], 4), "|", round(s.sd_weight[i], 4), "|\n")
}
cat("\n")

mean_of_sample_means <- mean(s.means_weight)
sd_of_sample_means <- sd(s.means_weight)

cat("Mean of Sample Means:", round(mean_of_sample_means, 4), "kg\n")
cat("Standard Deviation of Sample Means:", round(sd_of_sample_means, 4), "kg\n\n")

cat("| Population Mean |", round(popmean_weight, 4), "|\n")
cat("| Population Standard Deviation |", round(popsd_weight, 4), "|\n")
cat("| Mean of the Sample Means |", round(mean_of_sample_means, 4), "|\n")
cat("| Standard Deviation of Sample Means |", round(sd_of_sample_means, 4), "|\n")