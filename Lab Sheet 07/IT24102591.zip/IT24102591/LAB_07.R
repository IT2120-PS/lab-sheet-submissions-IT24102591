setwd("C:/Users/user/Desktop/IT24102591")

# Problem 1: Uniform Distribution
a <- 10
b <- 25
total_interval <- 40
P <- (b - a) / total_interval
P  

# Problem 2: Exponential Distribution
lambda <- 1/3
x <- 2
P_update <- 1 - exp(-lambda * x)
P_update  

# Problem 3: Normal Distribution
# i. Probability of IQ > 130
mu <- 100
sigma <- 15
X <- 130
Z <- (X - mu) / sigma
P_IQ_above_130 <- 1 - pnorm(Z)
P_IQ_above_130  

# ii. 95th Percentile IQ
percentile_95 <- qnorm(0.95, mean = mu, sd = sigma)
percentile_95  
